@extends('layouts.master')

@section('content')
	<h1>Welcome to my site</h1>
	<p>Hi, thanks for stopping by and learning more about me!</p>
@stop