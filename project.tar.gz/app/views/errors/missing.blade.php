@extends('layouts.master')

@section('content')
<h1>Error</h1>

@stop