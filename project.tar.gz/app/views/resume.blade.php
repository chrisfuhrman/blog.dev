@extends('layouts.master')

@section('content')
<h1>Resume</h1>
@stop