<?php

return array(
	'DB_HOST' => '',
	'DB_NAME' => '',
	'DB_USER' => '',
	'DB_PASS' => '',
	'DEFAULT_USER_EMAIL' => '',
	'DEFAULT_USER_PASSWORD' => '',
	'GOOGLE_CLIENT_ID' => '',
	'GOOGLE_CLIENT_SECRET' => ''
);